import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "U1 Atlas — Interactive Snapmaker U1 Study",
  description: "A local interactive exploded-view study of the Snapmaker U1 toolchanger 3D printer.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
