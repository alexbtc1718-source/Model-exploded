"use client";

import { useMemo, useState } from "react";
import { Box, Camera, Crosshair, Eye, EyeOff, Info, Layers3, RotateCcw, Search } from "lucide-react";
import { PrinterViewer, type PartInfo } from "@/components/printer-viewer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";

const groups = [
  { id: "all", label: "All systems", count: 32 },
  { id: "structure", label: "Structure", count: 11 },
  { id: "motion", label: "Motion", count: 7 },
  { id: "tooling", label: "Tooling", count: 8 },
  { id: "electronics", label: "Electronics", count: 4 },
  { id: "filament", label: "Filament", count: 2 },
];

const facts = [
  ["Architecture", "CoreXY toolchanger"],
  ["Build volume", "270 × 270 × 270 mm"],
  ["Toolheads", "4 independent"],
  ["Swap time", "about 5 seconds"],
];

export default function Home() {
  const [explode, setExplode] = useState(0);
  const [activeGroup, setActiveGroup] = useState("all");
  const [selected, setSelected] = useState<PartInfo | null>(null);
  const [query, setQuery] = useState("");
  const [labels, setLabels] = useState(true);
  const [resetKey, setResetKey] = useState(0);
  const filteredGroups = useMemo(() => groups.filter((group) => group.label.toLowerCase().includes(query.toLowerCase())), [query]);

  function resetView() {
    setExplode(0); setActiveGroup("all"); setSelected(null); setResetKey((value) => value + 1);
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand-mark" aria-hidden="true"><Box size={19} strokeWidth={1.7} /></div>
        <div className="brand-copy"><h1>U1 Atlas</h1><span>Interactive machine study</span></div>
        <div className="topbar-meta"><span className="status-dot" /><span>32 modeled assemblies</span><span className="divider" /><span>Concept model · v0.1</span></div>
        <Button className="reset-button" variant="outline" onClick={resetView}><RotateCcw size={15} /> Reset view</Button>
      </header>

      <section className="workspace">
        <aside className="left-panel panel">
          <div className="panel-heading"><div><p className="eyebrow">Assemblies</p><h2>Machine systems</h2></div><Layers3 size={18} /></div>
          <label className="search-box"><Search size={15} /><Input aria-label="Search systems" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Find a system" /></label>
          <nav className="system-list" aria-label="Printer systems">
            {filteredGroups.map((group) => (
              <button key={group.id} type="button" className={activeGroup === group.id ? "system-row active" : "system-row"} onClick={() => { setActiveGroup(group.id); setSelected(null); }}>
                <span className={`system-swatch swatch-${group.id}`} /><span>{group.label}</span><small>{group.count}</small>
              </button>
            ))}
          </nav>
          <div className="source-note"><Info size={15} /><p>Built from public product and support material. Shapes and internal placement are illustrative—not service CAD.</p></div>
        </aside>

        <div className="stage-wrap">
          <PrinterViewer explode={explode} activeGroup={activeGroup} labels={labels} selectedId={selected?.id ?? null} resetKey={resetKey} onSelect={setSelected} />
          <div className="stage-title"><p className="eyebrow">Snapmaker U1</p><h2>{explode > 0 ? "Exploded assembly" : "Complete assembly"}</h2></div>
          <div className="view-hint"><span>Drag to orbit</span><span>Scroll to zoom</span><span>Click a part</span></div>
          <div className="explode-control">
            <div className="explode-label">
              <div><p className="eyebrow">Assembly spacing</p><strong>{Math.round(explode * 100)}%</strong></div>
              <div className="toggle-label"><span>{explode > 0 ? "Exploded" : "Assembled"}</span><Switch aria-label="Toggle exploded view" checked={explode > 0} onCheckedChange={(checked) => setExplode(checked ? 1 : 0)} /></div>
            </div>
            <Slider aria-label="Explosion amount" min={0} max={100} step={1} value={[explode * 100]} onValueChange={(value) => setExplode(value[0] / 100)} />
            <div className="range-labels"><span>Joined</span><span>Service spacing</span></div>
          </div>
        </div>

        <aside className="right-panel panel">
          {selected ? (
            <div className="part-detail">
              <div className="panel-heading"><div><p className="eyebrow">Selected part</p><h2>{selected.name}</h2></div><Crosshair size={18} /></div>
              <div className={`detail-color swatch-${selected.group}`} />
              <p className="detail-description">{selected.description}</p>
              <dl><div><dt>System</dt><dd>{selected.groupLabel}</dd></div><div><dt>Basis</dt><dd>{selected.basis}</dd></div><div><dt>Model ID</dt><dd>{selected.id}</dd></div></dl>
              <Button variant="outline" className="wide-button" onClick={() => setSelected(null)}>Clear selection</Button>
            </div>
          ) : (
            <>
              <div className="panel-heading"><div><p className="eyebrow">Machine profile</p><h2>U1 overview</h2></div><Camera size={18} /></div>
              <div className="model-badge">PUBLIC-DOC MODEL</div>
              <p className="detail-description">A browser-native reconstruction focused on the U1’s visible architecture and service assemblies. Select any rendered part to inspect it.</p>
              <dl>{facts.map(([term, value]) => <div key={term}><dt>{term}</dt><dd>{value}</dd></div>)}</dl>
            </>
          )}
          <div className="visibility-card"><div>{labels ? <Eye size={16} /> : <EyeOff size={16} />}<span>Part labels</span></div><Switch aria-label="Toggle part labels" checked={labels} onCheckedChange={setLabels} /></div>
          <div className="legend"><p className="eyebrow">Color key</p>{groups.slice(1).map((group) => <button key={group.id} onClick={() => setActiveGroup(group.id)}><span className={`system-swatch swatch-${group.id}`} />{group.label}</button>)}</div>
        </aside>
      </section>
    </main>
  );
}
