"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

export type PartInfo = {
  id: string;
  name: string;
  group: "structure" | "motion" | "tooling" | "electronics" | "filament";
  groupLabel: string;
  description: string;
  basis: string;
};

type ViewerProps = { explode: number; activeGroup: string; labels: boolean; selectedId: string | null; resetKey: number; onSelect: (part: PartInfo | null) => void; };
type PartMesh = THREE.Mesh & { userData: { part?: PartInfo; home?: THREE.Vector3; explode?: THREE.Vector3; baseColor?: THREE.Color; } };

const palette = { structure: 0x9ba7b4, motion: 0x37c5e8, tooling: 0xf59b45, electronics: 0xb77df2, filament: 0x74d59d };
const groupNames = { structure: "Structure", motion: "Motion", tooling: "Tooling", electronics: "Electronics", filament: "Filament" };

function makePart(geometry: THREE.BufferGeometry, id: string, name: string, group: keyof typeof palette, position: [number, number, number], explosion: [number, number, number], description: string, basis = "Documented assembly; simplified geometry", color?: number) {
  const material = new THREE.MeshStandardMaterial({ color: color ?? palette[group], roughness: .44, metalness: group === "structure" || group === "motion" ? .5 : .18 });
  const mesh = new THREE.Mesh(geometry, material) as PartMesh;
  mesh.position.set(...position); mesh.castShadow = true; mesh.receiveShadow = true;
  mesh.userData.part = { id, name, group, groupLabel: groupNames[group], description, basis };
  mesh.userData.home = mesh.position.clone(); mesh.userData.explode = new THREE.Vector3(...explosion); mesh.userData.baseColor = new THREE.Color(color ?? palette[group]);
  return mesh;
}

export function PrinterViewer(props: ViewerProps) {
  const host = useRef<HTMLDivElement>(null);
  const onSelectRef = useRef(props.onSelect);
  const state = useRef<{ renderer: THREE.WebGLRenderer; scene: THREE.Scene; camera: THREE.PerspectiveCamera; controls: OrbitControls; parts: PartMesh[]; labels: HTMLDivElement[]; animation: number; hovered: PartMesh | null; targetExplode: number; currentExplode: number; activeGroup: string; selectedId: string | null; showLabels: boolean; } | null>(null);

  useEffect(() => { onSelectRef.current = props.onSelect; }, [props.onSelect]);

  useEffect(() => {
    if (!host.current) return;
    const container = host.current;
    const scene = new THREE.Scene(); scene.background = new THREE.Color(0x080b0e); scene.fog = new THREE.FogExp2(0x080b0e, .018);
    const camera = new THREE.PerspectiveCamera(34, 1, .1, 100); camera.position.set(8.8, 6.4, 10.5);
    const renderer = new THREE.WebGLRenderer({ antialias: true }); renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; renderer.outputColorSpace = THREE.SRGBColorSpace; container.appendChild(renderer.domElement);
    const controls = new OrbitControls(camera, renderer.domElement); controls.enableDamping = true; controls.target.set(0, 2.2, 0); controls.minDistance = 6; controls.maxDistance = 21; controls.maxPolarAngle = Math.PI * .83;

    scene.add(new THREE.HemisphereLight(0x9fdfff, 0x101216, 1.75));
    const key = new THREE.DirectionalLight(0xffffff, 3.1); key.position.set(5, 10, 7); key.castShadow = true; key.shadow.mapSize.set(1536, 1536); scene.add(key);
    const rim = new THREE.PointLight(0x19aee8, 18, 20); rim.position.set(-6, 4, -4); scene.add(rim);
    const stage = new THREE.Mesh(new THREE.CylinderGeometry(4.5, 4.85, .42, 64), new THREE.MeshStandardMaterial({ color: 0x11171c, metalness: .72, roughness: .36 })); stage.position.y = -.46; stage.receiveShadow = true; scene.add(stage);
    const stageRing = new THREE.Mesh(new THREE.TorusGeometry(4.62, .026, 8, 96), new THREE.MeshBasicMaterial({ color: 0x29c5ee })); stageRing.rotation.x = Math.PI / 2; stageRing.position.y = -.23; scene.add(stageRing);
    const grid = new THREE.GridHelper(24, 36, 0x183744, 0x111a20); grid.position.y = -.68; scene.add(grid);

    const parts: PartMesh[] = [];
    const box = (x: number, y: number, z: number) => new THREE.BoxGeometry(x, y, z, 2, 2, 2);
    const cyl = (r: number, h: number) => new THREE.CylinderGeometry(r, r, h, 24);
    const add = (part: PartMesh, rotation?: [number, number, number]) => { if (rotation) part.rotation.set(...rotation); parts.push(part); scene.add(part); };

    add(makePart(box(5.45,.45,5.25),"STR-001","Lower chassis","structure",[0,.02,0],[0,-2.2,0],"Welded all-metal foundation supporting the printer and electronics."));
    add(makePart(box(5.25,.18,4.9),"STR-002","Base deck","structure",[0,.32,0],[0,-1.35,0],"Internal floor above the lower electronics bay.","Visible architecture; approximate placement",0x4c5862));
    add(makePart(box(.22,5.2,.22),"STR-003","Front-left upright","structure",[-2.47,2.9,2.32],[-3.3,.6,2.4],"Front structural upright of the welded frame."));
    add(makePart(box(.22,5.2,.22),"STR-004","Front-right upright","structure",[2.47,2.9,2.32],[3.3,.6,2.4],"Front structural upright of the welded frame."));
    add(makePart(box(.22,5.2,.22),"STR-005","Rear-left upright","structure",[-2.47,2.9,-2.32],[-3.3,.6,-2.4],"Rear structural upright of the welded frame."));
    add(makePart(box(.22,5.2,.22),"STR-006","Rear-right upright","structure",[2.47,2.9,-2.32],[3.3,.6,-2.4],"Rear structural upright of the welded frame."));
    add(makePart(box(5.2,.2,.22),"STR-007","Front top beam","structure",[0,5.47,2.32],[0,2.6,3.2],"Upper crossmember tying the front uprights together."));
    add(makePart(box(5.2,.2,.22),"STR-008","Rear top beam","structure",[0,5.47,-2.32],[0,2.6,-3.2],"Upper rear crossmember and tool dock support."));
    add(makePart(box(.16,4.75,4.35),"STR-009","Left side panel","structure",[-2.58,2.83,0],[-5.1,.25,0],"Outer side panel attached to the metal frame.","Visible enclosure; simplified geometry",0x39444e));
    add(makePart(box(.16,4.75,4.35),"STR-010","Right side panel","structure",[2.58,2.83,0],[5.1,.25,0],"Outer side panel attached to the metal frame.","Visible enclosure; simplified geometry",0x39444e));
    add(makePart(box(5.08,4.75,.16),"STR-011","Rear panel","structure",[0,2.83,-2.48],[0,.25,-5.2],"Rear machine panel behind the toolhead docking area.","Visible enclosure; simplified geometry",0x303942));

    add(makePart(box(4.3,.12,4.3),"MOT-001","Heated build plate","motion",[0,1.05,.15],[0,-.2,4.2],"270 × 270 mm build platform, represented at the documented working scale.","Documented 270 mm build area",0x3b4650));
    add(makePart(box(4.05,.06,4.05),"MOT-002","Flexible build sheet","motion",[0,1.16,.15],[0,1.05,5.2],"Removable print surface above the heated bed.","Visible user-removable part",0x596a75));
    add(makePart(box(.16,4.35,.16),"MOT-003","Left Z guide","motion",[-2.12,2.86,-.1],[-3.65,0,-.3],"Vertical guide supporting Z motion.","Support imagery; simplified geometry",0x73838f));
    add(makePart(box(.16,4.35,.16),"MOT-004","Right Z guide","motion",[2.12,2.86,-.1],[3.65,0,-.3],"Vertical guide supporting Z motion.","Support imagery; simplified geometry",0x73838f));
    add(makePart(box(4.65,.14,.18),"MOT-005","Carbon-fiber X axis","motion",[0,4.12,.35],[0,1.65,1.2],"Lightweight carbon-fiber X-axis used to reduce moving mass.","Explicitly documented construction",0x1c252b));
    add(makePart(box(.55,.62,.38),"MOT-006","X carriage","motion",[.25,4,.42],[.5,2.2,2.5],"Carriage carrying the active toolhead across the X-axis.","Functional reconstruction",0x2787a2));
    const belt=makePart(new THREE.TorusGeometry(2.08,.025,6,64),"MOT-007","CoreXY belt path","motion",[0,5.12,0],[0,3.6,0],"Simplified continuous belt path for the documented CoreXY motion system.","Documented CoreXY; illustrative routing",0x26343c); belt.scale.z=.92; add(belt,[Math.PI/2,0,0]);

    const dockXs=[-1.68,-.56,.56,1.68];
    dockXs.forEach((x,index)=>{
      add(makePart(box(.92,.46,.32),`TLS-00${index+1}`,`Toolhead ${index+1} dock`,"tooling",[x,4.72,-2.13],[x*1.8,1.8,-3.8],"One of four rear docking positions in the SnapSwap toolchanging system.","Documented four-position docking architecture",0x555f68));
      const head=makePart(box(.74,1.05,.68),`TLS-01${index+1}`,`Independent toolhead ${index+1}`,"tooling",[x,4.05,-1.88],[x*2.2,.5+index*.45,-4.6],"Complete direct-drive toolhead with its own loaded filament path and nozzle.","Documented independent toolhead; exterior simplified",[0xf15b5d,0x35b7df,0xf0b33f,0x7dcf82][index]);
      const nozzle=new THREE.Mesh(new THREE.ConeGeometry(.07,.28,16),new THREE.MeshStandardMaterial({color:0xe8bf72,metalness:.75,roughness:.28})); nozzle.position.set(0,-.65,.06); nozzle.castShadow=true; head.add(nozzle); add(head);
    });

    add(makePart(box(1.1,.7,.32),"ELC-001","Touchscreen","electronics",[2.67,1.72,1.68],[4.6,.35,3.5],"3.5-inch touchscreen for local machine operation.","Documented display size",0x171d24),[0,-.25,0]);
    add(makePart(box(.48,.28,.22),"ELC-002","Monitoring camera","electronics",[-1.82,4.92,2.18],[-3.4,2.8,4.2],"Built-in camera for remote monitoring, time-lapse capture, and assisted issue detection.","Documented integrated camera",0x242c34));
    add(makePart(box(2.25,.28,1.75),"ELC-003","Main electronics bay","electronics",[0,.25,-.55],[0,-2.3,-2.2],"Simplified location for control and power electronics.","Internal arrangement is illustrative",0x3b2851));
    add(makePart(cyl(.42,.18),"ELC-004","Rear exhaust fan","electronics",[1.65,3.05,-2.55],[3.5,.2,-4.6],"Rear airflow component represented from visible product construction.","Visible feature; approximate dimensions",0x221b2c),[Math.PI/2,0,0]);
    add(makePart(box(.72,2.1,.46),"FIL-001","Auto-loading hub","filament",[-2.35,2.65,-1.4],[-5.2,1.1,-2.8],"Filament-management zone representing automatic loading and runout sensing.","Documented function; internal form illustrative",0x326349));
    add(makePart(box(.72,.72,.72),"FIL-002","Waste collector","filament",[2.25,.82,-1.65],[4.5,-.8,-3.8],"Collector for small waste from nozzle clearing, wiping, and calibration.","Documented removable collector",0x365e49));

    const labels=parts.map((part)=>{ const element=document.createElement("div"); element.className="part-label"; element.textContent=part.userData.part!.name; container.appendChild(element); return element; });
    const pointer=new THREE.Vector2(); const raycaster=new THREE.Raycaster();
    const appState={renderer,scene,camera,controls,parts,labels,animation:0,hovered:null as PartMesh|null,targetExplode:0,currentExplode:0,activeGroup:"all",selectedId:null as string|null,showLabels:true}; state.current=appState;
    const resize=()=>{ const width=container.clientWidth,height=container.clientHeight; renderer.setSize(width,height,false); camera.aspect=width/Math.max(height,1); camera.updateProjectionMatrix(); }; resize(); const observer=new ResizeObserver(resize); observer.observe(container);
    const pick=(event:PointerEvent,commit:boolean)=>{ const rect=renderer.domElement.getBoundingClientRect(); pointer.x=((event.clientX-rect.left)/rect.width)*2-1; pointer.y=-((event.clientY-rect.top)/rect.height)*2+1; raycaster.setFromCamera(pointer,camera); const hit=raycaster.intersectObjects(parts.filter((part)=>part.visible),false)[0]?.object as PartMesh|undefined; appState.hovered=hit??null; renderer.domElement.style.cursor=hit?"pointer":"grab"; if(commit) onSelectRef.current(hit?.userData.part??null); };
    const onMove=(event:PointerEvent)=>pick(event,false); const onClick=(event:PointerEvent)=>pick(event,true); renderer.domElement.addEventListener("pointermove",onMove); renderer.domElement.addEventListener("click",onClick);
    const clock=new THREE.Clock();
    const tick=()=>{ appState.animation=requestAnimationFrame(tick); const delta=Math.min(clock.getDelta(),.05); appState.currentExplode=THREE.MathUtils.damp(appState.currentExplode,appState.targetExplode,7,delta);
      parts.forEach((part,index)=>{ const home=part.userData.home!,offset=part.userData.explode!.clone().multiplyScalar(appState.currentExplode); part.position.lerp(home.clone().add(offset),1-Math.exp(-delta*10)); const matches=appState.activeGroup==="all"||part.userData.part!.group===appState.activeGroup; part.visible=matches; const material=part.material as THREE.MeshStandardMaterial; material.color.copy(part.userData.baseColor!); material.emissive.setHex(0); if(part.userData.part!.id===appState.selectedId){material.emissive.setHex(0x16495c);material.color.offsetHSL(0,0,.2);}else if(part===appState.hovered){material.emissive.setHex(0x12313d);} const label=labels[index],projected=part.position.clone().project(camera); const onScreen=projected.z<1&&Math.abs(projected.x)<1.05&&Math.abs(projected.y)<1.05; const allowed=appState.showLabels&&matches&&(appState.currentExplode>.33||part.userData.part!.id===appState.selectedId); label.style.display=onScreen&&allowed?"block":"none"; label.style.transform=`translate(-50%, -50%) translate(${(projected.x*.5+.5)*container.clientWidth}px, ${(-projected.y*.5+.5)*container.clientHeight}px)`; }); controls.update(); renderer.render(scene,camera); };
    tick();
    return()=>{ cancelAnimationFrame(appState.animation); observer.disconnect(); renderer.domElement.removeEventListener("pointermove",onMove); renderer.domElement.removeEventListener("click",onClick); labels.forEach((label)=>label.remove()); parts.forEach((part)=>{part.geometry.dispose();(part.material as THREE.Material).dispose();}); controls.dispose(); renderer.dispose(); renderer.domElement.remove(); state.current=null; };
  }, []);

  useEffect(()=>{if(state.current)state.current.targetExplode=props.explode;},[props.explode]);
  useEffect(()=>{if(state.current)state.current.activeGroup=props.activeGroup;},[props.activeGroup]);
  useEffect(()=>{if(state.current)state.current.selectedId=props.selectedId;},[props.selectedId]);
  useEffect(()=>{if(state.current)state.current.showLabels=props.labels;},[props.labels]);
  useEffect(()=>{if(!state.current)return;state.current.camera.position.set(8.8,6.4,10.5);state.current.controls.target.set(0,2.2,0);state.current.controls.update();},[props.resetKey]);
  return <div ref={host} className="three-stage" aria-label="Interactive 3D model of a Snapmaker U1 printer" />;
}
