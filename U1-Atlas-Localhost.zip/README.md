# U1 Atlas

An interactive, browser-based exploded-view study of the Snapmaker U1. The interaction model is inspired by the open-source [Human Atlas](https://github.com/ashemag/human-atlas), while all printer geometry in this project is an original, simplified reconstruction.

## Run locally

Requires Node.js 22.13 or newer.

```bash
pnpm install
pnpm dev
```

Open the local address shown in the terminal. Use `pnpm build` for a production build.

## Included interactions

- Orbit, zoom, and click-to-select 3D parts
- Animated exploded-view toggle and continuous spacing slider
- Filter by structure, motion, tooling, electronics, or filament systems
- Part labels, technical notes, mobile layout, and view reset

## Model scope

The model contains 32 selectable assemblies based on visible and publicly documented U1 architecture: welded frame, CoreXY motion, carbon-fiber X-axis, 270 mm build platform, four toolheads and docks, touchscreen, camera, electronics bay, loading area, and waste collector.

This is an educational concept model, not official Snapmaker CAD, a service manual, or a source of manufacturing dimensions. Internal forms and placements that are not shown in public documentation are deliberately labeled as illustrative.

## Public references

- [Snapmaker U1 official product page](https://www.snapmaker.com/en-US/snapmaker-u1)
- [Snapmaker U1 official wiki](https://wiki.snapmaker.com/en/snapmaker_u1)
- [Human Atlas reference project](https://github.com/ashemag/human-atlas)

Snapmaker and U1 are trademarks of their respective owner. This project is unaffiliated with Snapmaker.
