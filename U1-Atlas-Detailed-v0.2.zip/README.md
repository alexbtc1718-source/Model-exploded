# U1 Atlas

An interactive, browser-based exploded-view study of the Snapmaker U1. The interaction model is inspired by the open-source [Human Atlas](https://github.com/ashemag/human-atlas), while the printer geometry is an original procedural reconstruction from public Snapmaker imagery.

## Run locally

Requires Node.js 22.13 or newer.

```bash
pnpm install
pnpm dev
```

Open the local address shown in the terminal. Use `pnpm build` for a production build.

## Included interactions

- Orbit, zoom, and click-to-select 3D parts
- Animated exploded-view toggle and continuous spacing slider
- Filter by structure, motion, tooling, electronics, or filament systems
- Part labels, technical notes, mobile layout, and view reset

## Model scope

Version 0.2 contains 60 selectable assemblies: the white enclosure and front door, internal frame, CoreXY rails, carbon X gantry, belts, pulleys and motors, Z system, 270 mm bed stack, four detailed docked toolheads, active SnapSwap head, wiping and purge hardware, four external spool stations, individual PTFE paths, touchscreen, camera, lighting, cable chain, controller, PSU and exhaust system.

This is an educational concept model, not official Snapmaker CAD, a service manual, or a source of manufacturing dimensions. Internal forms and placements that are not shown in public documentation are deliberately labeled as illustrative.

## Public references

- [Snapmaker U1 official product page](https://www.snapmaker.com/en-US/snapmaker-u1)
- [Snapmaker U1 official wiki](https://wiki.snapmaker.com/en/snapmaker_u1)
- [Human Atlas reference project](https://github.com/ashemag/human-atlas)

Snapmaker and U1 are trademarks of their respective owner. This project is unaffiliated with Snapmaker.
